# RM AI Manager Pilot — Prep Pack v0.1

> 状态：Pilot Preparation，仅用于未来 Manager 实验；**不是 RM_AI_Development_Protocol v2.3 的一部分，也不修改 v2.3 Frozen。**
>
> 目标：把“状态导航与上下文组装”从用户手工维护中卸载出来，同时不把 Manager 变成新的项目总监督。

## 1. Manager 的定位

Manager 是：

> **Control Plane / Navigator / State Coordinator**

它帮助回答：

- 当前项目大致处于什么状态？
- 哪些对话 / 角色正在工作？
- 某件事应该去哪个对话处理？
- 新对话需要携带哪些上下文？
- 哪份状态 / Report / Checkpoint 是当前最新入口？
- 当前 Protocol 版本是什么，升级后项目需要做什么？

它不是：

- Main Supervisor；
- 技术路线决策者；
- Debug Agent；
- Work / Codex Executor；
- Knowledge Teacher；
- Protocol Maintainer。

**Manager 是地图，不是指挥链。**

---

## 2. 第一版只验证 5 个能力

1. `status`：快速恢复当前项目、对话、协议和知识状态的导航摘要。
2. `where / route`：告诉用户当前问题应该进入哪个已有对话 / 角色，或是否值得新开对话。
3. `ingest`：读取正式 `STATE_UPDATE`，更新 Manager 索引。
4. `bootstrap`：为新对话生成最小充分 `BOOTSTRAP_PACKET`。
5. `protocol-update`：读取 Protocol Maintainer 提交的 `PROTOCOL_RELEASE_PACKET`，更新协议索引与迁移提醒。

第一版**不开发插件、不开发自动状态机、不自动修改业务仓库**。

---

## 3. 与 v2.3 的关系

Manager 必须复用 v2.3 已有规则，而不是重做它们：

- `common/Context_Health.md`：判断何时需要重新锚定 / 恢复；
- `common/Handoff_Protocol.md`：Minimum Sufficient Handoff；
- `common/Carry_Forward.md`：下一阶段必须带走什么；
- `project/Project_State_Convention.md`：项目事实的权威入口；
- `entries/Supervisor_Entry.md` / `entries/Specialist_Entry.md`：角色职责；
- `playbooks/knowledge/*`：知识学习和资产状态；
- `templates/*`：现有正式 Report / Brief / Checkpoint / State 模板。

Manager 只新增：

> **跨角色导航索引 + 状态更新入口 + Bootstrap 组装。**

---

## 4. Source of Truth 规则

优先级：

```text
Authoritative Artifact
    > Manager Control Index
    > Manager 对话中的临时总结
```

Manager 可以自己维护机械状态，例如：

- 某对话 Active / Paused / Completed；
- 最新 Artifact 路径；
- Last Updated；
- 当前 Protocol Version；
- 某条索引是否 stale。

Manager **不能自行创造语义状态**，例如：

- “P0 已完成”；
- “正式进入 P1”；
- “技术路线 A 已被采用”；
- “用户已经掌握 EKF”；
- “Specialist 结论已被主线接受”。

这类状态必须来自用户、Main Supervisor、正式 Report / Decision / Learning State 等权威来源。

---

## 5. 第一版推荐目录

```text
rm-ai-control/
├── AGENTS.md                         # 可选：宿主环境的全局说明
├── protocol/                         # 当前协议及 Release Packet
├── control/
│   └── PROJECT_CONTROL_INDEX.md      # Manager 维护的地图
├── inbox/                            # STATE_UPDATE / RELEASE_PACKET
├── outbox/                           # BOOTSTRAP_PACKET 等输出
└── .agents/
    └── skills/
        └── rm-project-manager/
            └── SKILL.md
```

本包只提供设计与模板，不要求现在就按此创建真实仓库。

---

## 6. 未来启用时的最小流程

### 初始化

1. 放入当前 `RM_AI_Development_Protocol_v2.3_Frozen`；
2. 用 `PROJECT_CONTROL_INDEX_TEMPLATE.md` 建立最小 Control Index；
3. 把 `seed/PROTOCOL_RELEASE_PACKET_v2.3_INITIAL.md` 作为第一份协议基线输入；
4. 只登记当前真正活跃的项目 / 对话 / Knowledge State，不回填全部历史。

### 日常使用

```text
用户问导航问题
→ Manager 读 Control Index
→ 必要时读权威 Artifact
→ 回答 / 生成 Bootstrap
```

重大事件发生：

```text
Supervisor / Specialist / Knowledge / Maintainer
→ 产生正式 Artifact 或 STATE_UPDATE
→ Manager ingest
→ 更新 Control Index
```

不是每轮对话都汇报。

---

## 7. Pilot 成功标准

只有当它明显减少下面这些人工负担，Manager 才值得长期保留：

- “我现在在哪个阶段？”
- “这件事该去哪个对话？”
- “我以前学过这个吗？”
- “哪份状态文件最新？”
- “新对话该带什么？”
- “协议升级后我要做什么？”

如果 Manager 自己变成一个需要用户频繁维护的新项目，则 Pilot 失败。

---

## 8. 当前不做

- DSH Plugin；
- 数据库；
- 自动 Knowledge Graph；
- 自动扫描全部聊天；
- 自动决定项目阶段；
- 自动合并项目状态；
- 自动修改业务代码；
- 自动接受 Specialist 结论；
- 自动升级 Protocol。

先验证文件 + Skill + 对话是否足够。
